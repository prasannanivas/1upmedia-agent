import React from "react";

export default function Agents() {
  return <div>Agents</div>;
}
