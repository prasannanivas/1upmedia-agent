// pages/Publishing.js
import React from "react";

const Publishing = () => {
  return <div>Publishing Page</div>;
};

export default Publishing;
