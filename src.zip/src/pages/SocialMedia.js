// pages/SocialMedia.js
import React from "react";

const SocialMedia = () => {
  return <div>Social Media Page</div>;
};

export default SocialMedia;
