import React from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import StepMainDomain from "./Steps/StepMainDomain";
import StepIntegrations from "./Steps/StepIntegrations";
import StepKeywords from "./Steps/StepKeywords";
// import StepBusinessDetails from "./steps/StepBusinessDetails";
// import StepSocialIntegrations from "./steps/StepSocialIntegrations";
// import StepPersonas from "./steps/StepPersonas";
// import StepContentStrategy from "./steps/StepContentStrategy";

const Onboarding = () => {
  const navigate = useNavigate();

  const handleSkip = () => {
    navigate("/dashboard"); // Skip onboarding and navigate to the dashboard
  };

  return (
    <div className="Onboarding">
      <h1>Onboarding Workflow</h1>
      <Routes>
        <Route path="/" element={<Navigate to="step-main-domain" />} />
        <Route path="step-main-domain" element={<StepMainDomain />} />
        <Route path="step-integrations" element={<StepIntegrations />} />
        <Route path="step-keywords" element={<StepKeywords />} />
        {/* <Route path="step-business-details" element={<StepBusinessDetails />} />
        <Route
          path="step-social-integrations"
          element={<StepSocialIntegrations />}
        />
        <Route path="step-personas" element={<StepPersonas />} />
        <Route path="step-content-strategy" element={<StepContentStrategy />} /> */}
      </Routes>
      <button onClick={handleSkip}>Skip Onboarding</button>
    </div>
  );
};

export default Onboarding;
