import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useOnboarding } from "../../../context/OnboardingContext";

const Step2 = () => {
  const { onboardingData, setOnboardingData } = useOnboarding();
  const [integrations, setIntegrations] = useState(onboardingData.integrations);
  const navigate = useNavigate();

  const handleIntegrationChange = (integration) => {
    setIntegrations((prev) =>
      prev.includes(integration)
        ? prev.filter((item) => item !== integration)
        : [...prev, integration]
    );
  };

  const handleNext = () => {
    setOnboardingData((prev) => ({ ...prev, integrations }));
    navigate("/onboarding/step3");
  };

  return (
    <div>
      <h2>Step 2: Integrations</h2>
      <label>
        <input
          type="checkbox"
          checked={integrations.includes("Google Analytics")}
          onChange={() => handleIntegrationChange("Google Analytics")}
        />
        Google Analytics
      </label>
      <label>
        <input
          type="checkbox"
          checked={integrations.includes("WordPress")}
          onChange={() => handleIntegrationChange("WordPress")}
        />
        WordPress
      </label>
      <button onClick={handleNext}>Next</button>
    </div>
  );
};

export default Step2;
