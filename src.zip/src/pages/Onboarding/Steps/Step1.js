import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useOnboarding } from "../../../context/OnboardingContext";

const Step1 = () => {
  const { onboardingData, setOnboardingData } = useOnboarding();
  const [domain, setDomain] = useState(onboardingData.domain);
  const navigate = useNavigate();

  const handleNext = () => {
    setOnboardingData((prev) => ({ ...prev, domain }));
    navigate("/onboarding/step2");
  };

  return (
    <div>
      <h2>Step 1: Main Domain Setup</h2>
      <input
        type="text"
        placeholder="Enter your domain"
        value={domain}
        onChange={(e) => setDomain(e.target.value)}
      />
      <button onClick={handleNext}>Next</button>
    </div>
  );
};

export default Step1;
