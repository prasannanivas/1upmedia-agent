import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useOnboarding } from "../../../context/OnboardingContext";

const Step3 = () => {
  const { onboardingData, setOnboardingData } = useOnboarding();
  const [keywords, setKeywords] = useState(onboardingData.keywords);
  const navigate = useNavigate();

  const handleAddKeyword = (keyword) => {
    setKeywords((prev) => [...prev, keyword]);
  };

  const handleFinish = () => {
    setOnboardingData((prev) => ({ ...prev, keywords }));
    navigate("/dashboard");
  };

  return (
    <div>
      <h2>Step 3: Keywords</h2>
      <input
        type="text"
        placeholder="Enter a keyword"
        onKeyDown={(e) => {
          if (e.key === "Enter" && e.target.value.trim()) {
            handleAddKeyword(e.target.value.trim());
            e.target.value = "";
          }
        }}
      />
      <ul>
        {keywords.map((keyword, index) => (
          <li key={index}>{keyword}</li>
        ))}
      </ul>
      <button onClick={handleFinish}>Finish</button>
    </div>
  );
};

export default Step3;
