import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useOnboarding } from "../../../context/OnboardingContext";

const StepKeywords = () => {
  const { setKeywords } = useOnboarding();
  const [keyword, setKeyword] = useState("");
  const [keywordList, setKeywordList] = useState([]);
  const navigate = useNavigate();

  const handleAddKeyword = () => {
    if (keyword) {
      setKeywordList((prev) => [...prev, keyword]);
      setKeyword("");
    }
  };

  const handleNext = () => {
    setKeywords(keywordList);
    navigate("/onboarding/step-business-details");
  };

  return (
    <div>
      <h2>Define Keywords</h2>
      <input
        type="text"
        placeholder="Enter keyword"
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
      />
      <button onClick={handleAddKeyword}>Add Keyword</button>
      <ul>
        {keywordList.map((kw, index) => (
          <li key={index}>{kw}</li>
        ))}
      </ul>
      <button onClick={handleNext}>Next</button>
    </div>
  );
};

export default StepKeywords;
