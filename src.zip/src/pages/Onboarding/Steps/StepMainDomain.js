import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useOnboarding } from "../../../context/OnboardingContext";

const StepMainDomain = () => {
  const { setDomain, setLanguage } = useOnboarding();
  const [domain, setDomainInput] = useState("");
  const [language, setLanguageInput] = useState("");
  const navigate = useNavigate();

  const handleNext = () => {
    setDomain(domain);
    setLanguage(language);
    navigate("/onboarding/step-integrations");
  };

  return (
    <div>
      <h2>Main Domain Setup</h2>
      <input
        type="text"
        placeholder="Enter your domain"
        value={domain}
        onChange={(e) => setDomainInput(e.target.value)}
      />
      <input
        type="text"
        placeholder="Select Language"
        value={language}
        onChange={(e) => setLanguageInput(e.target.value)}
      />
      <button onClick={handleNext}>Next</button>
    </div>
  );
};

export default StepMainDomain;
