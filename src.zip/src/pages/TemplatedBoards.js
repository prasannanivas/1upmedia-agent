// pages/TemplatedBoards.js
import React from "react";

const TemplatedBoards = () => {
  return <div>Templated Boards Page</div>;
};

export default TemplatedBoards;
