// pages/CustomBoards.js
import React from "react";

const CustomBoards = () => {
  return <div>Custom Boards Page</div>;
};

export default CustomBoards;
