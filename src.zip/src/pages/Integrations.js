import React from "react";

function Integrations() {
  return <div>Integrations</div>;
}

export default Integrations;
