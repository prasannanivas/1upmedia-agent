// pages/ContentReview.js
import React from "react";

const ContentReview = () => {
  return <div>Content Review Page</div>;
};

export default ContentReview;
