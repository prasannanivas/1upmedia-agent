import React from "react";

function Boards() {
  return <div>Boards</div>;
}

export default Boards;
