// pages/Security.js
import React from "react";

const Security = () => {
  return <div>Security Page</div>;
};

export default Security;
